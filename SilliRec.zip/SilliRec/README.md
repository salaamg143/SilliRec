# SilliRec

A dark, hacker-terminal styled Android audio recorder built in Kotlin + Jetpack Compose.
Records **microphone**, **internal/system audio** (Android 10+, via MediaProjection), or **both**,
with a foreground service, a persistent notification, and a slim 2×1 home-screen widget that
stays perfectly in sync with the app.

- Package: `silli.rec.app`
- Min SDK: 24 • Target SDK: 34
- UI: pure black `#0A0A0A`, matrix green `#00FF41`, JetBrains Mono, sharp corners, live waveform

---

## ⚠ About the APK
This ZIP contains the **complete source project**, not a prebuilt `.apk`.
The build sandbox used to generate this project has **no Android SDK, no Gradle, and no internet**,
so a compiled APK could not be produced here. Building takes ~2 minutes on your machine:

### Option A — Android Studio (easiest)
1. Unzip `SilliRec.zip`.
2. Open Android Studio → **Open** → select the `SilliRec` folder.
3. Let it sync Gradle (downloads dependencies automatically).
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
5. APK appears at `app/build/outputs/apk/debug/app-debug.apk`.

### Option B — Command line
```bash
cd SilliRec
# Generate the Gradle wrapper jar once (needs internet):
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

> Note: `gradlew`/`gradlew.bat` and `gradle-wrapper.jar` are not bundled (the jar is a binary that
> could not be generated offline). Android Studio creates them automatically, or run
> `gradle wrapper` once as shown above.

---

## Features
- **Sources:** Mic / Internal / Both (toggle chips). Internal uses `AudioPlaybackCaptureConfiguration`.
- **Formats:** M4A (AAC via MediaCodec+MediaMuxer) and WAV (PCM16).
- **Foreground service** with live duration + **Pause/Stop** notification actions.
- **Home-screen widget** (2×1): app name, live timer, single toggle — green when idle, red when recording.
- **Live animated waveform** driven by real RMS amplitude.
- **Recordings library** tab with duration, size, date, delete.

## Edge cases handled
- Android 10+ guard for internal audio capture.
- Battery-optimization exemption prompt so the service survives in the background.
- Phone-call interruption → auto-pause, then auto-resume after the call.
- Storage-full check before and during recording.
- Correct `PendingIntent` flags (`FLAG_IMMUTABLE`) for Android 12+.
- Foreground service types `microphone|mediaProjection` + Android 13 notification permission.

## Project structure
```
app/src/main/java/silli/rec/app/
  MainActivity.kt              # Compose host, permissions, projection consent
  model/Models.kt              # AudioSource, OutputFormat, RecorderState, Recording
  audio/                       # AudioRecorderEngine, WavFileWriter, M4aEncoder, constants
  service/                     # RecordingService (foreground) + RecordingController (shared state)
  widget/SilliRecWidgetProvider.kt
  ui/theme/                    # Color, Type (JetBrains Mono), Theme (sharp shapes)
  ui/components/               # Waveform, SourceChips, FormatSelector, RecordButton
  ui/screens/                  # HomeScreen, LibraryScreen, MainScreen (tabs)
  util/Utils.kt                # Time, Storage, Battery helpers
  data/RecordingsRepository.kt
res/                           # colors, themes, strings, widget layout, drawables, launcher icon
```

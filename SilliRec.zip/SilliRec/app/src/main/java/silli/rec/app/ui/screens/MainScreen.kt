package silli.rec.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.Recording
import silli.rec.app.model.RecorderState
import silli.rec.app.ui.theme.MatrixGreen
import silli.rec.app.ui.theme.MatrixGreenFaint
import silli.rec.app.ui.theme.TerminalBlack
import silli.rec.app.ui.theme.TextDim

private enum class Tab(val label: String) { HOME("[ REC ]"), LIBRARY("[ LIBRARY ]") }

@Composable
fun MainScreen(
    state: RecorderState,
    recordings: List<Recording>,
    onSourceChange: (AudioSource) -> Unit,
    onFormatChange: (OutputFormat) -> Unit,
    onToggleRecord: () -> Unit,
    onPauseResume: () -> Unit,
    onDeleteRecording: (Recording) -> Unit,
    onRefreshLibrary: () -> Unit,
) {
    var tab by remember { mutableStateOf(Tab.HOME) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBlack),
    ) {
        // Terminal header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(BorderStroke(1.dp, MatrixGreenFaint), RectangleShape)
                .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Text(
                text = "root@silli:~/rec\$ SilliRec",
                color = MatrixGreen,
                fontWeight = FontWeight.Bold,
            )
        }

        // Tab bar
        Row(Modifier.fillMaxWidth()) {
            Tab.values().forEach { t ->
                val selected = t == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(BorderStroke(1.dp, if (selected) MatrixGreen else MatrixGreenFaint), RectangleShape)
                        .background(if (selected) MatrixGreen.copy(alpha = 0.10f) else Color.Transparent)
                        .clickable {
                            tab = t
                            if (t == Tab.LIBRARY) onRefreshLibrary()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = t.label,
                        color = if (selected) MatrixGreen else TextDim,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }

        Box(Modifier.fillMaxSize()) {
            when (tab) {
                Tab.HOME -> HomeScreen(
                    state = state,
                    onSourceChange = onSourceChange,
                    onFormatChange = onFormatChange,
                    onToggleRecord = onToggleRecord,
                    onPauseResume = onPauseResume,
                )
                Tab.LIBRARY -> LibraryScreen(recordings = recordings, onDelete = onDeleteRecording)
            }
        }
    }
}

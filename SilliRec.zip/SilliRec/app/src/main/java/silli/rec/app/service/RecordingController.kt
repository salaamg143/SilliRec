package silli.rec.app.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.RecorderState
import silli.rec.app.model.RecorderStatus

/**
 * Single source of truth for recorder state.
 *
 * The [RecordingService] is the only writer. The Compose UI collects [state] as a flow,
 * while the home-screen widget reads [snapshot] synchronously (it cannot observe flows).
 * This keeps the widget and the app perfectly in sync because both ultimately read the
 * same object that the service updates.
 */
object RecordingController {

    private val _state = MutableStateFlow(RecorderState())
    val state: StateFlow<RecorderState> = _state.asStateFlow()

    /** Synchronous snapshot for the widget / quick checks. */
    val snapshot: RecorderState get() = _state.value

    val isActive: Boolean get() = _state.value.isActive
    val isRecording: Boolean get() = _state.value.status == RecorderStatus.RECORDING

    // ---- Writers (service only) ----

    internal fun update(transform: (RecorderState) -> RecorderState) {
        _state.value = transform(_state.value)
    }

    internal fun setStarting(source: AudioSource, format: OutputFormat, filePath: String) {
        _state.value = RecorderState(
            status = RecorderStatus.RECORDING,
            source = source,
            format = format,
            elapsedMs = 0L,
            currentFilePath = filePath,
        )
    }

    internal fun setElapsed(ms: Long) = update { it.copy(elapsedMs = ms) }

    internal fun setAmplitude(amp: Float) = update { it.copy(amplitude = amp) }

    internal fun setStatus(status: RecorderStatus) = update { it.copy(status = status) }

    internal fun setError(message: String?) = update { it.copy(errorMessage = message) }

    internal fun reset() {
        _state.value = RecorderState(
            source = _state.value.source,
            format = _state.value.format,
        )
    }
}

package silli.rec.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import silli.rec.app.MainActivity
import silli.rec.app.R
import silli.rec.app.model.AudioSource
import silli.rec.app.model.RecorderStatus
import silli.rec.app.service.RecordingController
import silli.rec.app.service.RecordingService
import silli.rec.app.util.TimeUtils

/**
 * Slim 2x1 home-screen widget. Shows the app name, the live recording timer, and a single
 * on/off toggle (green when idle, red when recording). It stays in sync with the app because
 * both read [RecordingController], and the service calls [refresh] on every state change.
 */
class SilliRecWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> manager.updateAppWidget(id, buildViews(context)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_WIDGET_TOGGLE) {
            val snapshot = RecordingController.snapshot
            if (snapshot.isActive) {
                // Stop directly through the service.
                context.startService(
                    Intent(context, RecordingService::class.java).setAction(RecordingService.ACTION_STOP),
                )
            } else if (snapshot.source == AudioSource.MIC) {
                // Mic-only can start straight from the widget.
                val start = Intent(context, RecordingService::class.java).apply {
                    action = RecordingService.ACTION_START
                    putExtra(RecordingService.EXTRA_SOURCE, snapshot.source.name)
                    putExtra(RecordingService.EXTRA_FORMAT, snapshot.format.name)
                }
                RecordingService.startForegroundCompat(context, start)
            } else {
                // Internal/Both need MediaProjection consent -> open the app to grant it.
                val launch = Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
            }
            refresh(context)
        }
    }

    companion object {
        const val ACTION_WIDGET_TOGGLE = "silli.rec.app.widget.TOGGLE"

        /** Re-render every instance of the widget from the latest controller snapshot. */
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, SilliRecWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return
            val views = buildViewsStatic(context)
            ids.forEach { manager.updateAppWidget(it, views) }
        }

        private fun buildViewsStatic(context: Context): RemoteViews = build(context)

        private fun build(context: Context): RemoteViews {
            val state = RecordingController.snapshot
            val recording = state.status == RecorderStatus.RECORDING
            val paused = state.status == RecorderStatus.PAUSED
            val views = RemoteViews(context.packageName, R.layout.widget_silli_rec)

            views.setTextViewText(R.id.widget_title, "SilliRec")
            views.setTextViewText(
                R.id.widget_timer,
                if (state.isActive) TimeUtils.formatDuration(state.elapsedMs) else "--:--",
            )

            val toggleLabel = when {
                recording -> "■ STOP"
                paused -> "▶ RESUME"
                else -> "● REC"
            }
            views.setTextViewText(R.id.widget_toggle, toggleLabel)
            views.setInt(
                R.id.widget_toggle,
                "setBackgroundResource",
                if (state.isActive) R.drawable.widget_toggle_active else R.drawable.widget_toggle_idle,
            )

            // Toggle button -> broadcast to this provider.
            val toggleIntent = Intent(context, SilliRecWidgetProvider::class.java)
                .setAction(ACTION_WIDGET_TOGGLE)
            views.setOnClickPendingIntent(
                R.id.widget_toggle,
                PendingIntent.getBroadcast(context, 100, toggleIntent, pendingFlags()),
            )

            // Tapping the body opens the app.
            val openIntent = Intent(context, MainActivity::class.java)
            views.setOnClickPendingIntent(
                R.id.widget_root,
                PendingIntent.getActivity(context, 101, openIntent, pendingFlags()),
            )
            return views
        }

        private fun pendingFlags(): Int =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
    }
}

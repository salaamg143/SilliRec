package silli.rec.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import silli.rec.app.ui.theme.MatrixGreen
import silli.rec.app.ui.theme.MatrixGreenFaint
import kotlin.math.sin

/**
 * Live scrolling waveform. Each new amplitude (0f..1f) pushes a bar onto a rolling buffer.
 * When idle, a faint animated sine ripple keeps the terminal feeling "alive".
 */
@Composable
fun Waveform(
    amplitude: Float,
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 56,
) {
    val bars = remember { mutableStateListOf<Float>().apply { repeat(barCount) { add(0f) } } }

    LaunchedEffect(amplitude, isActive) {
        if (isActive) {
            bars.removeAt(0)
            bars.add(amplitude.coerceIn(0f, 1f))
        }
    }

    val transition = rememberInfiniteTransition(label = "idle-wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "phase",
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp),
    ) {
        val count = bars.size
        val gap = 3.dp.toPx()
        val barWidth = (size.width - gap * (count - 1)) / count
        val midY = size.height / 2f
        for (i in 0 until count) {
            val raw = if (isActive) {
                bars[i]
            } else {
                (sin(phase + i * 0.35f) * 0.5f + 0.5f) * 0.12f
            }
            val barHeight = (raw * size.height).coerceAtLeast(2f)
            val x = i * (barWidth + gap)
            drawLine(
                color = if (isActive) MatrixGreen else MatrixGreenFaint,
                start = Offset(x + barWidth / 2f, midY - barHeight / 2f),
                end = Offset(x + barWidth / 2f, midY + barHeight / 2f),
                strokeWidth = barWidth,
                cap = StrokeCap.Square,
            )
        }
    }
}

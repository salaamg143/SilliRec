package silli.rec.app.audio

import android.media.AudioFormat
import android.media.AudioRecord

object AudioConstants {
    const val SAMPLE_RATE = 44_100
    const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_ENCODING = AudioFormat.ENCODING_PCM_16BIT
    const val CHANNEL_COUNT = 1
    const val BITS_PER_SAMPLE = 16

    /** Minimum buffer rounded up to a comfortable size for steady reads. */
    val bufferSize: Int by lazy {
        val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_ENCODING)
        if (min <= 0) SAMPLE_RATE * 2 else min * 2
    }
}

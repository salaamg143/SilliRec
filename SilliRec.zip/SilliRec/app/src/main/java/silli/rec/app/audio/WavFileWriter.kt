package silli.rec.app.audio

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile

/**
 * Streams PCM16 data into a .wav file. Header is written up-front with placeholder
 * sizes and patched on [close] once the total byte count is known.
 */
class WavFileWriter(private val file: File) {

    private val out = BufferedOutputStream(FileOutputStream(file))
    private var dataBytes = 0L

    init {
        writeHeader(0)
    }

    fun write(buffer: ByteArray, length: Int) {
        out.write(buffer, 0, length)
        dataBytes += length
    }

    fun close() {
        out.flush()
        out.close()
        patchHeaderSizes()
    }

    private fun writeHeader(dataLen: Int) {
        val sampleRate = AudioConstants.SAMPLE_RATE
        val channels = AudioConstants.CHANNEL_COUNT
        val bits = AudioConstants.BITS_PER_SAMPLE
        val byteRate = sampleRate * channels * bits / 8
        val blockAlign = channels * bits / 8
        val header = ByteArray(44)

        // RIFF chunk
        "RIFF".toByteArray().copyInto(header, 0)
        writeIntLE(header, 4, 36 + dataLen)
        "WAVE".toByteArray().copyInto(header, 8)
        // fmt chunk
        "fmt ".toByteArray().copyInto(header, 12)
        writeIntLE(header, 16, 16)
        writeShortLE(header, 20, 1) // PCM
        writeShortLE(header, 22, channels)
        writeIntLE(header, 24, sampleRate)
        writeIntLE(header, 28, byteRate)
        writeShortLE(header, 32, blockAlign)
        writeShortLE(header, 34, bits)
        // data chunk
        "data".toByteArray().copyInto(header, 36)
        writeIntLE(header, 40, dataLen)
        out.write(header, 0, 44)
    }

    private fun patchHeaderSizes() {
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(4)
            raf.write(intLE(36 + dataBytes.toInt()))
            raf.seek(40)
            raf.write(intLE(dataBytes.toInt()))
        }
    }

    private fun writeIntLE(b: ByteArray, off: Int, value: Int) {
        b[off] = (value and 0xff).toByte()
        b[off + 1] = ((value shr 8) and 0xff).toByte()
        b[off + 2] = ((value shr 16) and 0xff).toByte()
        b[off + 3] = ((value shr 24) and 0xff).toByte()
    }

    private fun writeShortLE(b: ByteArray, off: Int, value: Int) {
        b[off] = (value and 0xff).toByte()
        b[off + 1] = ((value shr 8) and 0xff).toByte()
    }

    private fun intLE(value: Int): ByteArray = byteArrayOf(
        (value and 0xff).toByte(),
        ((value shr 8) and 0xff).toByte(),
        ((value shr 16) and 0xff).toByte(),
        ((value shr 24) and 0xff).toByte(),
    )
}

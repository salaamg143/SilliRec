package silli.rec.app.audio

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import androidx.annotation.RequiresPermission
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import java.io.File
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Owns the raw [AudioRecord] instances and the encoder. Runs a tight read loop on a
 * dedicated thread, mixes mic + internal PCM when [AudioSource.BOTH] is selected, computes
 * a normalized amplitude for the waveform, and forwards encoded bytes to the chosen writer.
 */
class AudioRecorderEngine(
    private val context: Context,
    private val source: AudioSource,
    private val format: OutputFormat,
    private val outputFile: File,
    private val mediaProjection: MediaProjection?,
    private val onAmplitude: (Float) -> Unit,
    private val onError: (String) -> Unit,
    private val isStorageLow: () -> Boolean,
) {

    @Volatile private var running = false
    @Volatile private var paused = false
    private var thread: Thread? = null

    private var micRecord: AudioRecord? = null
    private var internalRecord: AudioRecord? = null

    private var wavWriter: WavFileWriter? = null
    private var m4aEncoder: M4aEncoder? = null

    fun setPaused(value: Boolean) { paused = value }

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start() {
        if (running) return
        running = true
        when (format) {
            OutputFormat.WAV -> wavWriter = WavFileWriter(outputFile)
            OutputFormat.M4A -> m4aEncoder = M4aEncoder(outputFile)
        }
        thread = Thread({ loop() }, "SilliRec-Audio").also { it.start() }
    }

    @SuppressLint("MissingPermission")
    private fun buildMic(): AudioRecord = AudioRecord(
        MediaRecorder.AudioSource.MIC,
        AudioConstants.SAMPLE_RATE,
        AudioConstants.CHANNEL_CONFIG,
        AudioConstants.AUDIO_ENCODING,
        AudioConstants.bufferSize,
    )

    @SuppressLint("MissingPermission")
    private fun buildInternal(projection: MediaProjection): AudioRecord {
        // Internal/system audio capture is only available on Android 10 (API 29)+.
        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val audioFormat = AudioFormat.Builder()
            .setEncoding(AudioConstants.AUDIO_ENCODING)
            .setSampleRate(AudioConstants.SAMPLE_RATE)
            .setChannelMask(AudioConstants.CHANNEL_CONFIG)
            .build()
        return AudioRecord.Builder()
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(AudioConstants.bufferSize)
            .setAudioPlaybackCaptureConfig(config)
            .build()
    }

    private fun loop() {
        try {
            if (source.needsMic) {
                micRecord = buildMic().also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) {
                        onError("Microphone could not be initialized")
                        return
                    }
                    it.startRecording()
                }
            }
            if (source.needsProjection) {
                val projection = mediaProjection
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || projection == null) {
                    onError("Internal audio needs Android 10+ and screen-capture consent")
                    return
                }
                internalRecord = buildInternal(projection).also {
                    if (it.state != AudioRecord.STATE_INITIALIZED) {
                        onError("Internal audio could not be initialized")
                        return
                    }
                    it.startRecording()
                }
            }

            val micBuf = ByteArray(AudioConstants.bufferSize)
            val intBuf = ByteArray(AudioConstants.bufferSize)
            val mixBuf = ByteArray(AudioConstants.bufferSize)

            while (running) {
                if (paused) {
                    Thread.sleep(50)
                    continue
                }
                if (isStorageLow()) {
                    onError("Storage full — recording stopped")
                    break
                }

                val micLen = micRecord?.read(micBuf, 0, micBuf.size) ?: 0
                val intLen = internalRecord?.read(intBuf, 0, intBuf.size) ?: 0

                val (outBuf, outLen) = when (source) {
                    AudioSource.MIC -> micBuf to micLen
                    AudioSource.INTERNAL -> intBuf to intLen
                    AudioSource.BOTH -> {
                        val n = mix(micBuf, micLen, intBuf, intLen, mixBuf)
                        mixBuf to n
                    }
                }

                if (outLen > 0) {
                    writeOut(outBuf, outLen)
                    onAmplitude(rms(outBuf, outLen))
                }
            }
        } catch (e: Exception) {
            onError(e.message ?: "Recording failed")
        } finally {
            releaseInternals()
        }
    }

    private fun writeOut(buf: ByteArray, len: Int) {
        when (format) {
            OutputFormat.WAV -> wavWriter?.write(buf, len)
            OutputFormat.M4A -> m4aEncoder?.encode(buf, len)
        }
    }

    /** Sample-wise additive mix of two PCM16 streams with clipping protection. */
    private fun mix(a: ByteArray, aLen: Int, b: ByteArray, bLen: Int, out: ByteArray): Int {
        val n = min(min(aLen, bLen), out.size)
        var i = 0
        while (i + 1 < n) {
            val s1 = (a[i].toInt() and 0xff) or (a[i + 1].toInt() shl 8)
            val s2 = (b[i].toInt() and 0xff) or (b[i + 1].toInt() shl 8)
            var mixed = s1 + s2
            if (mixed > Short.MAX_VALUE) mixed = Short.MAX_VALUE.toInt()
            if (mixed < Short.MIN_VALUE) mixed = Short.MIN_VALUE.toInt()
            out[i] = (mixed and 0xff).toByte()
            out[i + 1] = ((mixed shr 8) and 0xff).toByte()
            i += 2
        }
        return n
    }

    /** Normalized RMS amplitude in 0f..1f for the waveform visualizer. */
    private fun rms(buf: ByteArray, len: Int): Float {
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < len) {
            val sample = ((buf[i].toInt() and 0xff) or (buf[i + 1].toInt() shl 8)).toShort()
            sum += sample.toDouble() * sample.toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0f
        val rms = sqrt(sum / count)
        return (rms / Short.MAX_VALUE).toFloat().coerceIn(0f, 1f)
    }

    fun stop() {
        running = false
        thread?.join(1_000)
        thread = null
        runCatching { wavWriter?.close() }
        runCatching { m4aEncoder?.close() }
        wavWriter = null
        m4aEncoder = null
    }

    private fun releaseInternals() {
        runCatching { micRecord?.stop() }
        runCatching { micRecord?.release() }
        runCatching { internalRecord?.stop() }
        runCatching { internalRecord?.release() }
        micRecord = null
        internalRecord = null
    }
}

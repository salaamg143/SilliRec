package silli.rec.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

// Sharp corners EVERYWHERE: 0dp radius on all shape tokens.
private val SharpShapes = Shapes(
    extraSmall = RoundedCornerShape(0.dp),
    small = RoundedCornerShape(0.dp),
    medium = RoundedCornerShape(0.dp),
    large = RoundedCornerShape(0.dp),
    extraLarge = RoundedCornerShape(0.dp),
)

private val TerminalColorScheme = darkColorScheme(
    primary = MatrixGreen,
    onPrimary = TerminalBlack,
    secondary = MatrixGreen,
    onSecondary = TerminalBlack,
    background = TerminalBlack,
    onBackground = MatrixGreen,
    surface = TerminalBlack,
    onSurface = MatrixGreen,
    surfaceVariant = TerminalBlackElevated,
    onSurfaceVariant = MatrixGreenDim,
    error = RecordingRed,
    onError = TerminalBlack,
    outline = TerminalGrey,
)

@Composable
fun SilliRecTheme(content: @Composable () -> Unit) {
    // Always dark terminal theme regardless of system setting.
    @Suppress("UNUSED_VARIABLE")
    val ignored = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = TerminalTypography,
        shapes = SharpShapes,
        content = content,
    )
}

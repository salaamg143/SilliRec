package silli.rec.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import silli.rec.app.model.Recording
import silli.rec.app.ui.theme.MatrixGreen
import silli.rec.app.ui.theme.MatrixGreenFaint
import silli.rec.app.ui.theme.TextDim
import silli.rec.app.util.StorageUtils
import silli.rec.app.util.TimeUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LibraryScreen(recordings: List<Recording>, onDelete: (Recording) -> Unit) {
    if (recordings.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("> no recordings yet", color = TextDim)
        }
        return
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(recordings, key = { it.filePath }) { rec ->
            RecordingRow(rec, onDelete)
        }
    }
}

@Composable
private fun RecordingRow(rec: Recording, onDelete: (Recording) -> Unit) {
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy • HH:mm", Locale.US) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, MatrixGreenFaint), RectangleShape)
            .padding(12.dp),
    ) {
        Column(Modifier.fillMaxWidth(0.85f)) {
            Text(
                text = rec.name,
                color = MatrixGreen,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "[${rec.format.label}] " +
                    TimeUtils.formatDuration(rec.durationMs) +
                    "  •  " + StorageUtils.formatSize(rec.sizeBytes),
                color = TextDim,
            )
            Text(text = dateFmt.format(Date(rec.createdAt)), color = TextDim)
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            IconButton(onClick = { onDelete(rec) }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = MatrixGreen)
            }
        }
    }
}

package silli.rec.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.core.content.ContextCompat
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.RecorderStatus
import silli.rec.app.service.RecordingController
import silli.rec.app.service.RecordingService
import silli.rec.app.ui.screens.MainScreen
import silli.rec.app.ui.theme.SilliRecTheme
import silli.rec.app.data.RecordingsRepository
import silli.rec.app.util.BatteryUtils

class MainActivity : ComponentActivity() {

    private lateinit var repo: RecordingsRepository
    private var pendingSource: AudioSource = AudioSource.MIC
    private var pendingFormat: OutputFormat = OutputFormat.M4A

    private val recordingsState = mutableStateOf<List<silli.rec.app.model.Recording>>(emptyList())

    // Runtime permission launcher (mic + notifications on Android 13+).
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { /* result handled lazily on next record attempt */ }

    // MediaProjection consent launcher for internal audio.
    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startServiceWithProjection(result.resultCode, result.data!!)
        } else {
            RecordingController.setError("Screen-capture permission denied")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = RecordingsRepository(this)
        requestStartupPermissions()
        maybePromptBatteryOptimization()

        setContent {
            SilliRecTheme {
                val state by RecordingController.state.collectAsState()
                val recordings by remember { recordingsState }

                MainScreen(
                    state = state,
                    recordings = recordings,
                    onSourceChange = { src ->
                        pendingSource = src
                        RecordingController.update { it.copy(source = src) }
                    },
                    onFormatChange = { fmt ->
                        pendingFormat = fmt
                        RecordingController.update { it.copy(format = fmt) }
                    },
                    onToggleRecord = { onToggleRecord() },
                    onPauseResume = { onPauseResume() },
                    onDeleteRecording = { rec ->
                        repo.delete(rec)
                        recordingsState.value = repo.listRecordings()
                    },
                    onRefreshLibrary = { recordingsState.value = repo.listRecordings() },
                )
            }
        }
    }

    private fun onToggleRecord() {
        if (RecordingController.isActive) {
            send(RecordingService.ACTION_STOP)
            recordingsState.value = repo.listRecordings()
            return
        }
        val source = RecordingController.snapshot.source
        val format = RecordingController.snapshot.format
        pendingSource = source
        pendingFormat = format

        if (source.needsProjection) {
            // Edge case: internal capture only on Android 10+.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                RecordingController.setError("Internal audio needs Android 10 or newer")
                return
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        } else {
            startServiceMicOnly()
        }
    }

    private fun onPauseResume() {
        when (RecordingController.snapshot.status) {
            RecorderStatus.RECORDING -> send(RecordingService.ACTION_PAUSE)
            RecorderStatus.PAUSED -> send(RecordingService.ACTION_RESUME)
            else -> {}
        }
    }

    private fun startServiceMicOnly() {
        val intent = Intent(this, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_SOURCE, pendingSource.name)
            putExtra(RecordingService.EXTRA_FORMAT, pendingFormat.name)
        }
        RecordingService.startForegroundCompat(this, intent)
    }

    private fun startServiceWithProjection(resultCode: Int, data: Intent) {
        val intent = Intent(this, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra(RecordingService.EXTRA_SOURCE, pendingSource.name)
            putExtra(RecordingService.EXTRA_FORMAT, pendingFormat.name)
            putExtra(RecordingService.EXTRA_RESULT_CODE, resultCode)
            putExtra(RecordingService.EXTRA_RESULT_DATA, data)
        }
        RecordingService.startForegroundCompat(this, intent)
    }

    private fun send(action: String) {
        val intent = Intent(this, RecordingService::class.java).setAction(action)
        RecordingService.startForegroundCompat(this, intent)
    }

    private fun requestStartupPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    // Edge case: prompt user to exempt the app from battery optimization so the
    // foreground service is not killed in the background.
    private fun maybePromptBatteryOptimization() {
        if (!BatteryUtils.supportsBatteryOptimization()) return
        if (BatteryUtils.isIgnoringBatteryOptimizations(this)) return
        runCatching {
            @Suppress("BatteryLife")
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        recordingsState.value = repo.listRecordings()
    }
}

package silli.rec.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RectangleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.RecorderStatus
import silli.rec.app.ui.theme.MatrixGreen
import silli.rec.app.ui.theme.MatrixGreenFaint
import silli.rec.app.ui.theme.RecordingRed
import silli.rec.app.ui.theme.TerminalBlack
import silli.rec.app.ui.theme.TextDim

/** Row of sharp-cornered selectable chips. */
@Composable
fun <T> SelectorRow(
    options: List<T>,
    selected: T,
    enabled: Boolean,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            val isSel = option == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .border(
                        BorderStroke(1.dp, if (isSel) MatrixGreen else TerminalBlack.copy(alpha = 1f).let { MatrixGreenFaint }),
                        RectangleShape,
                    )
                    .background(if (isSel) MatrixGreen.copy(alpha = 0.12f) else Color.Transparent)
                    .clickable(enabled = enabled) { onSelect(option) }
                    .alpha(if (enabled) 1f else 0.4f)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label(option),
                    color = if (isSel) MatrixGreen else TextDim,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
fun SourceChips(selected: AudioSource, enabled: Boolean, onSelect: (AudioSource) -> Unit) {
    SelectorRow(
        options = AudioSource.values().toList(),
        selected = selected,
        enabled = enabled,
        label = { it.label },
        onSelect = onSelect,
    )
}

@Composable
fun FormatSelector(selected: OutputFormat, enabled: Boolean, onSelect: (OutputFormat) -> Unit) {
    SelectorRow(
        options = OutputFormat.values().toList(),
        selected = selected,
        enabled = enabled,
        label = { it.label },
        onSelect = onSelect,
    )
}

/**
 * Big glowing record button. Pulses green when idle, turns into a red square when recording.
 */
@Composable
fun RecordButton(status: RecorderStatus, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val recording = status != RecorderStatus.IDLE
    val transition = rememberInfiniteTransition(label = "glow")
    val glow by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glowAlpha",
    )
    val ringColor by animateColorAsState(
        targetValue = if (recording) RecordingRed else MatrixGreen,
        label = "ring",
    )

    Box(
        modifier = modifier.size(160.dp),
        contentAlignment = Alignment.Center,
    ) {
        // Outer glow ring
        Box(
            modifier = Modifier
                .size(160.dp)
                .alpha(if (recording) 0.6f else glow)
                .border(BorderStroke(2.dp, ringColor), RectangleShape),
        )
        // Inner button
        Box(
            modifier = Modifier
                .size(110.dp)
                .scale(if (recording) 0.7f else 1f)
                .background(ringColor.copy(alpha = if (recording) 1f else 0.16f))
                .border(BorderStroke(2.dp, ringColor), RectangleShape)
                .clickable { onClick() },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = if (recording) "■ STOP" else "● REC",
                color = if (recording) Color.White else MatrixGreen,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

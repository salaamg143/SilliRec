package silli.rec.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core terminal palette. Matrix green is the ONLY accent.
val TerminalBlack = Color(0xFF0A0A0A)
val TerminalBlackElevated = Color(0xFF111111)
val TerminalGrey = Color(0xFF2A2A2A)
val MatrixGreen = Color(0xFF00FF41)
val MatrixGreenDim = Color(0x9900FF41)
val MatrixGreenFaint = Color(0x3300FF41)
val RecordingRed = Color(0xFFFF1744)
val RecordingRedDim = Color(0x99FF1744)
val TextDim = Color(0xFF6F6F6F)

package silli.rec.app.data

import android.content.Context
import android.media.MediaMetadataRetriever
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.Recording
import silli.rec.app.util.StorageUtils
import java.io.File

/** Reads finished recordings from the app's external files dir for the library tab. */
class RecordingsRepository(private val context: Context) {

    fun listRecordings(): List<Recording> {
        val dir = StorageUtils.recordingsDir(context)
        val files = dir.listFiles { f -> f.isFile && (f.extension == "m4a" || f.extension == "wav") }
            ?: return emptyList()
        return files.sortedByDescending { it.lastModified() }.map { it.toRecording() }
    }

    fun delete(recording: Recording): Boolean = File(recording.filePath).delete()

    private fun File.toRecording(): Recording {
        val format = if (extension == "wav") OutputFormat.WAV else OutputFormat.M4A
        val duration = runCatching {
            MediaMetadataRetriever().use { mmr ->
                mmr.setDataSource(absolutePath)
                mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            }
        }.getOrDefault(0L)
        return Recording(
            filePath = absolutePath,
            name = name,
            sizeBytes = length(),
            durationMs = duration,
            createdAt = lastModified(),
            format = format,
        )
    }
}

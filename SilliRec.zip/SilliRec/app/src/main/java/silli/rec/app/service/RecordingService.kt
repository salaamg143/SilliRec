package silli.rec.app.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import silli.rec.app.MainActivity
import silli.rec.app.R
import silli.rec.app.audio.AudioRecorderEngine
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.RecorderStatus
import silli.rec.app.util.StorageUtils
import silli.rec.app.util.TimeUtils
import silli.rec.app.widget.SilliRecWidgetProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground service that owns the entire recording lifecycle. It is the single
 * coordinator that both the app UI and the home-screen widget talk to, which guarantees
 * they stay in sync (both read [RecordingController]).
 */
class RecordingService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private var timerJob: Job? = null
    private var engine: AudioRecorderEngine? = null

    private var startElapsedRef = 0L
    private var accumulatedMs = 0L

    private var mediaProjection: MediaProjection? = null
    private var telephonyManager: TelephonyManager? = null
    private var callReceiver: BroadcastReceiver? = null
    private var autoPausedByCall = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_TOGGLE -> handleToggle(intent)
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> stopRecording()
        }
        return START_STICKY
    }

    // ---- Lifecycle actions ----

    private fun handleToggle(intent: Intent) {
        if (RecordingController.isActive) {
            stopRecording()
        } else {
            handleStart(intent)
        }
    }

    private fun handleStart(intent: Intent) {
        if (RecordingController.isActive) return

        val source = AudioSource.valueOf(
            intent.getStringExtra(EXTRA_SOURCE) ?: RecordingController.snapshot.source.name,
        )
        val format = OutputFormat.valueOf(
            intent.getStringExtra(EXTRA_FORMAT) ?: RecordingController.snapshot.format.name,
        )

        // Edge case: storage full before we even begin.
        if (StorageUtils.isStorageLow(this)) {
            RecordingController.setError("Not enough storage to start recording")
            stopSelf()
            return
        }

        // Edge case: internal capture requires Android 10+ and a projection token.
        if (source.needsProjection) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE)
            val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                RecordingController.setError("Internal audio needs Android 10 or newer")
                stopSelf()
                return
            }
            if (resultCode == Int.MIN_VALUE || data == null) {
                RecordingController.setError("Screen-capture permission was not granted")
                stopSelf()
                return
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpm.getMediaProjection(resultCode, data).also {
                it.registerCallback(projectionCallback, null)
            }
        }

        val file = newRecordingFile(format)
        // Promote to foreground BEFORE touching the microphone (Android 12+ requirement).
        startForeground(NOTIFICATION_ID, buildNotification(RecorderStatus.RECORDING, 0L))

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            RecordingController.setError("Microphone permission not granted")
            stopRecording()
            return
        }

        engine = AudioRecorderEngine(
            context = this,
            source = source,
            format = format,
            outputFile = file,
            mediaProjection = mediaProjection,
            onAmplitude = { amp -> RecordingController.setAmplitude(amp) },
            onError = { msg ->
                RecordingController.setError(msg)
                scope.launch { stopRecording() }
            },
            isStorageLow = { StorageUtils.isStorageLow(this) },
        )

        accumulatedMs = 0L
        startElapsedRef = System.currentTimeMillis()
        RecordingController.setStarting(source, format, file.absolutePath)
        runCatching { engine?.start() }.onFailure {
            RecordingController.setError(it.message ?: "Could not start recorder")
            stopRecording()
            return
        }
        registerCallInterruptionListener()
        startTimer()
        pushWidgetUpdate()
    }

    private fun pause() {
        if (RecordingController.snapshot.status != RecorderStatus.RECORDING) return
        engine?.setPaused(true)
        accumulatedMs += System.currentTimeMillis() - startElapsedRef
        RecordingController.setStatus(RecorderStatus.PAUSED)
        timerJob?.cancel()
        updateNotification(RecorderStatus.PAUSED, RecordingController.snapshot.elapsedMs)
        pushWidgetUpdate()
    }

    private fun resume() {
        if (RecordingController.snapshot.status != RecorderStatus.PAUSED) return
        engine?.setPaused(false)
        startElapsedRef = System.currentTimeMillis()
        RecordingController.setStatus(RecorderStatus.RECORDING)
        startTimer()
        updateNotification(RecorderStatus.RECORDING, RecordingController.snapshot.elapsedMs)
        pushWidgetUpdate()
    }

    private fun stopRecording() {
        timerJob?.cancel()
        timerJob = null
        runCatching { engine?.stop() }
        engine = null
        unregisterCallInterruptionListener()
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        RecordingController.reset()
        pushWidgetUpdate()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---- Timer ----

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (true) {
                val elapsed = accumulatedMs + (System.currentTimeMillis() - startElapsedRef)
                RecordingController.setElapsed(elapsed)
                updateNotification(RecorderStatus.RECORDING, elapsed)
                pushWidgetUpdate()
                delay(1_000)
            }
        }
    }

    // ---- Phone-call interruption (auto pause/resume) ----

    private fun registerCallInterruptionListener() {
        val filter = IntentFilter("android.intent.action.PHONE_STATE")
        callReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val stateStr = intent?.getStringExtra(TelephonyManager.EXTRA_STATE)
                when (stateStr) {
                    TelephonyManager.EXTRA_STATE_RINGING,
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                        if (RecordingController.snapshot.status == RecorderStatus.RECORDING) {
                            autoPausedByCall = true
                            pause()
                        }
                    }
                    TelephonyManager.EXTRA_STATE_IDLE -> {
                        if (autoPausedByCall &&
                            RecordingController.snapshot.status == RecorderStatus.PAUSED
                        ) {
                            autoPausedByCall = false
                            resume()
                        }
                    }
                }
            }
        }
        runCatching {
            ContextCompat.registerReceiver(
                this, callReceiver, filter, ContextCompat.RECEIVER_EXPORTED,
            )
        }
        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
    }

    private fun unregisterCallInterruptionListener() {
        callReceiver?.let { runCatching { unregisterReceiver(it) } }
        callReceiver = null
        autoPausedByCall = false
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            scope.launch { stopRecording() }
        }
    }

    // ---- Notification ----

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.channel_recording_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = getString(R.string.channel_recording_desc)
                setSound(null, null)
                enableVibration(false)
            }
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: RecorderStatus, elapsedMs: Long): Notification {
        val title = if (status == RecorderStatus.PAUSED) {
            getString(R.string.notif_paused_title)
        } else {
            getString(R.string.notif_recording_title)
        }
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            pendingFlags(),
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_rec_dot)
            .setContentTitle(title)
            .setContentText(TimeUtils.formatDuration(elapsedMs))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .setColor(0xFF00FF41.toInt())
            .setUsesChronometer(false)

        if (status == RecorderStatus.PAUSED) {
            builder.addAction(0, getString(R.string.action_resume), servicePending(ACTION_RESUME, 1))
        } else {
            builder.addAction(0, getString(R.string.action_pause), servicePending(ACTION_PAUSE, 2))
        }
        builder.addAction(0, getString(R.string.action_stop), servicePending(ACTION_STOP, 3))
        return builder.build()
    }

    private fun updateNotification(status: RecorderStatus, elapsedMs: Long) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(status, elapsedMs))
    }

    private fun servicePending(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, RecordingService::class.java).setAction(action)
        return PendingIntent.getService(this, requestCode, intent, pendingFlags())
    }

    // ---- Widget sync ----

    private fun pushWidgetUpdate() {
        SilliRecWidgetProvider.refresh(this)
    }

    private fun newRecordingFile(format: OutputFormat): File {
        val dir = StorageUtils.recordingsDir(this)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(dir, "SilliRec_$stamp.${format.extension}")
    }

    override fun onDestroy() {
        super.onDestroy()
        timerJob?.cancel()
        runCatching { engine?.stop() }
        unregisterCallInterruptionListener()
        runCatching { mediaProjection?.stop() }
    }

    companion object {
        const val CHANNEL_ID = "silli_rec_recording"
        const val NOTIFICATION_ID = 4201

        const val ACTION_START = "silli.rec.app.action.START"
        const val ACTION_STOP = "silli.rec.app.action.STOP"
        const val ACTION_PAUSE = "silli.rec.app.action.PAUSE"
        const val ACTION_RESUME = "silli.rec.app.action.RESUME"
        const val ACTION_TOGGLE = "silli.rec.app.action.TOGGLE"

        const val EXTRA_SOURCE = "extra_source"
        const val EXTRA_FORMAT = "extra_format"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        /** Correct mutability flags for PendingIntents on Android 12 (S)+. */
        fun pendingFlags(): Int {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
        }

        fun startForegroundCompat(context: Context, intent: Intent) {
            ContextCompat.startForegroundService(context, intent)
        }
    }
}

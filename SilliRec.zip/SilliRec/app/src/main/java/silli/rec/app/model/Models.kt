package silli.rec.app.model

/** Which audio source(s) to capture. */
enum class AudioSource(val label: String) {
    MIC("MIC"),
    INTERNAL("INTERNAL"),
    BOTH("BOTH");

    /** Internal capture requires MediaProjection (Android 10+). */
    val needsProjection: Boolean
        get() = this == INTERNAL || this == BOTH

    val needsMic: Boolean
        get() = this == MIC || this == BOTH
}

/** Output container/encoding. */
enum class OutputFormat(val label: String, val extension: String, val mime: String) {
    M4A("M4A", "m4a", "audio/mp4a-latm"),
    WAV("WAV", "wav", "audio/wav");
}

/** High-level recorder status shared between service, UI and widget. */
enum class RecorderStatus { IDLE, RECORDING, PAUSED }

/** Immutable snapshot of the recorder, observed by the UI and rendered by the widget. */
data class RecorderState(
    val status: RecorderStatus = RecorderStatus.IDLE,
    val source: AudioSource = AudioSource.MIC,
    val format: OutputFormat = OutputFormat.M4A,
    val elapsedMs: Long = 0L,
    val amplitude: Float = 0f,
    val currentFilePath: String? = null,
    val errorMessage: String? = null,
) {
    val isActive: Boolean get() = status != RecorderStatus.IDLE
}

/** A finished recording shown in the library tab. */
data class Recording(
    val filePath: String,
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val createdAt: Long,
    val format: OutputFormat,
)

package silli.rec.app.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import silli.rec.app.model.AudioSource
import silli.rec.app.model.OutputFormat
import silli.rec.app.model.RecorderState
import silli.rec.app.model.RecorderStatus
import silli.rec.app.ui.components.FormatSelector
import silli.rec.app.ui.components.RecordButton
import silli.rec.app.ui.components.SourceChips
import silli.rec.app.ui.components.Waveform
import silli.rec.app.ui.theme.MatrixGreen
import silli.rec.app.ui.theme.RecordingRed
import silli.rec.app.ui.theme.TextDim
import silli.rec.app.util.TimeUtils

@Composable
fun HomeScreen(
    state: RecorderState,
    onSourceChange: (AudioSource) -> Unit,
    onFormatChange: (OutputFormat) -> Unit,
    onToggleRecord: () -> Unit,
    onPauseResume: () -> Unit,
) {
    val idle = state.status == RecorderStatus.IDLE
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Status line
        val blink = rememberInfiniteTransition(label = "blink")
        val dot by blink.animateFloat(
            initialValue = 0.2f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "dot",
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            val statusText = when (state.status) {
                RecorderStatus.IDLE -> "● IDLE"
                RecorderStatus.RECORDING -> "● REC"
                RecorderStatus.PAUSED -> "∥ PAUSED"
            }
            Text(
                text = statusText,
                color = if (idle) TextDim else RecordingRed,
                modifier = Modifier.alpha(if (state.status == RecorderStatus.RECORDING) dot else 1f),
            )
        }

        Spacer(Modifier.height(8.dp))

        // Live timer
        Text(
            text = TimeUtils.formatDuration(state.elapsedMs),
            color = MatrixGreen,
            fontSize = 52.sp,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.height(16.dp))

        // Waveform visualizer
        Waveform(
            amplitude = state.amplitude,
            isActive = state.status == RecorderStatus.RECORDING,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(20.dp))

        Text("// SOURCE", color = TextDim, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        SourceChips(selected = state.source, enabled = idle, onSelect = onSourceChange)

        Spacer(Modifier.height(16.dp))

        Text("// FORMAT", color = TextDim, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        FormatSelector(selected = state.format, enabled = idle, onSelect = onFormatChange)

        Spacer(Modifier.height(28.dp))

        RecordButton(status = state.status, onClick = onToggleRecord)

        Spacer(Modifier.height(16.dp))

        if (!idle) {
            Text(
                text = if (state.status == RecorderStatus.PAUSED) "> tap to RESUME" else "> tap to PAUSE",
                color = TextDim,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                textAlign = TextAlign.Center,
            )
            androidx.compose.material3.TextButton(onClick = onPauseResume) {
                Text(
                    text = if (state.status == RecorderStatus.PAUSED) "[ RESUME ]" else "[ PAUSE ]",
                    color = MatrixGreen,
                )
            }
        }

        state.errorMessage?.let { err ->
            Spacer(Modifier.height(8.dp))
            Text(text = "! $err", color = RecordingRed, textAlign = TextAlign.Center)
        }
    }
}

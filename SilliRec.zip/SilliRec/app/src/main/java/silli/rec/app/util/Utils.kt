package silli.rec.app.util

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.StatFs
import java.io.File
import java.util.Locale

object TimeUtils {
    /** Formats milliseconds as HH:MM:SS (or MM:SS under an hour). */
    fun formatDuration(ms: Long): String {
        val totalSeconds = ms / 1000
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }
}

object StorageUtils {
    private const val LOW_STORAGE_THRESHOLD_BYTES = 50L * 1024 * 1024 // 50 MB

    fun recordingsDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "recordings")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun availableBytes(context: Context): Long {
        val path = context.getExternalFilesDir(null) ?: context.filesDir
        val stat = StatFs(path.absolutePath)
        return stat.availableBytes
    }

    fun isStorageLow(context: Context): Boolean =
        availableBytes(context) < LOW_STORAGE_THRESHOLD_BYTES

    fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }
}

object BatteryUtils {
    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun supportsBatteryOptimization(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
}

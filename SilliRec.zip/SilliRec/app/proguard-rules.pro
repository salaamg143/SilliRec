# Keep AppWidgetProvider and Service entry points referenced from the manifest.
-keep class silli.rec.app.widget.** { *; }
-keep class silli.rec.app.service.** { *; }

# Compose
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
